package com.example.clipboard;

public class ClipboardEntry {
    public String content;
    public long timestamp;
    public boolean pinned;
    public boolean favorite;

    public ClipboardEntry(String content, long timestamp, boolean pinned, boolean favorite) {
        this.content = content;
        this.timestamp = timestamp;
        this.pinned = pinned;
        this.favorite = favorite;
    }
}