package com.example.clipboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ClipboardScreen extends Screen {
    private static final int WIDTH = 320, HEIGHT = 240, ENTRY_HEIGHT = 24, VISIBLE_ENTRIES = 6;

    // 布局常量：标题栏高 24，标签栏在标题栏下方
    private static final int TITLE_H = 24;
    private static final int TAB_Y = 26;
    private static final int ENTRY_START_Y = 48;

    private int x, y, dragOffsetX, dragOffsetY, scrollOffset = 0, currentTab = 0;
    private boolean dragging = false;
    private ClipboardStorage storage;

    private final List<Button> entryButtons = new ArrayList<>();
    private Button historyTabBtn;
    private Button favoriteTabBtn;

    public ClipboardScreen() { super(Component.literal("Clipboard")); }

    @Override
    protected void init() {
        this.x = (this.width - WIDTH) / 2;
        this.y = (this.height - HEIGHT) / 2;
        loadStorage();

        // 标签按钮放在标题栏下方，不与拖动区域重叠
        historyTabBtn = Button.builder(
            Component.literal("历史"),
            b -> switchTab(0))
            .bounds(x + 8, y + TAB_Y, 60, 16).build();

        favoriteTabBtn = Button.builder(
            Component.literal("收藏"),
            b -> switchTab(1))
            .bounds(x + 72, y + TAB_Y, 60, 16).build();

        addRenderableWidget(historyTabBtn);
        addRenderableWidget(favoriteTabBtn);

        addRenderableWidget(Button.builder(Component.literal("清理历史"),
            b -> {
                if (hasShiftDown()) {
                    storage.entries.clear();
                } else {
                    storage.pruneUnprotected();
                }
                storage.setDirty();
                rebuildEntryList();
            })
            .bounds(x + 8, y + HEIGHT - 28, 80, 20).build());

        addRenderableWidget(Button.builder(Component.literal("关闭"), b -> this.onClose())
            .bounds(x + WIDTH - 88, y + HEIGHT - 28, 80, 20).build());

        rebuildEntryList();
    }

    private void loadStorage() {
        ClipboardStorage s = ClipboardMod.activeStorage;
        if (s == null) {
            s = ClipboardMod.getStorage();
        }
        if (s == null) {
            s = ClipboardStorage.create();
        }
        storage = s;
        ClipboardMod.activeStorage = s;
    }

    private void switchTab(int tab) {
        currentTab = tab;
        scrollOffset = 0;
        long favCount = storage.entries.stream().filter(e -> e.favorite).count();
        System.out.println("[Clipboard] 切标签 -> " + (tab == 0 ? "历史" : "收藏")
                         + " storage=" + System.identityHashCode(storage)
                         + " active=" + System.identityHashCode(ClipboardMod.activeStorage)
                         + " entries=" + storage.entries.size()
                         + " favorites=" + favCount);
        rebuildEntryList();
    }

    private void rebuildEntryList() {
        for (Button b : entryButtons) {
            removeWidget(b);
        }
        entryButtons.clear();

        if (historyTabBtn != null) {
            historyTabBtn.setMessage(Component.literal(currentTab == 0 ? "§l历史" : "历史"));
        }
        if (favoriteTabBtn != null) {
            favoriteTabBtn.setMessage(Component.literal(currentTab == 1 ? "§l收藏" : "收藏"));
        }

        List<ClipboardEntry> filtered = getFilteredEntries();
        int visible = Math.min(VISIBLE_ENTRIES, filtered.size() - scrollOffset);

        for (int i = 0; i < visible; i++) {
            ClipboardEntry entry = filtered.get(scrollOffset + i);
            int entryY = y + ENTRY_START_Y + i * ENTRY_HEIGHT;
            String display = entry.content.length() > 24
                ? entry.content.substring(0, 24) + "…" : entry.content;

            Button contentBtn = Button.builder(Component.literal(display),
                b -> pasteToChat(entry.content))
                .bounds(x + 8, entryY, 180, 20).build();

            Button pinBtn = Button.builder(
                Component.literal(entry.pinned ? "📌" : "📍"),
                b -> {
                    entry.pinned = !entry.pinned;
                    storage.setDirty();
                    rebuildEntryList();
                })
                .bounds(x + 192, entryY, 24, 20).build();

            Button favBtn = Button.builder(
                Component.literal(entry.favorite ? "⭐" : "☆"),
                b -> {
                    entry.favorite = !entry.favorite;
                    storage.setDirty();
                    System.out.println("[Clipboard] 切换 favorite: " + entry.content
                                     + " -> " + entry.favorite);
                    rebuildEntryList();
                })
                .bounds(x + 220, entryY, 24, 20).build();

            Button delBtn = Button.builder(Component.literal("✕"),
                b -> {
                    storage.entries.remove(entry);
                    storage.setDirty();
                    rebuildEntryList();
                })
                .bounds(x + 248, entryY, 24, 20).build();

            entryButtons.add(contentBtn);
            entryButtons.add(pinBtn);
            entryButtons.add(favBtn);
            entryButtons.add(delBtn);

            addRenderableWidget(contentBtn);
            addRenderableWidget(pinBtn);
            addRenderableWidget(favBtn);
            addRenderableWidget(delBtn);
        }
    }

    private void pasteToChat(String text) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(new ChatScreen(text));
    }

    private List<ClipboardEntry> getFilteredEntries() {
        if (currentTab == 1) {
            return storage.entries.stream().filter(e -> e.favorite).toList();
        }
        return storage.entries.stream()
            .sorted((a, b) -> Boolean.compare(b.pinned, a.pinned)).toList();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // 点击标签按钮时，交给 super 处理，不触发拖动
        if (historyTabBtn != null && historyTabBtn.isMouseOver(mx, my)) {
            return super.mouseClicked(mx, my, button);
        }
        if (favoriteTabBtn != null && favoriteTabBtn.isMouseOver(mx, my)) {
            return super.mouseClicked(mx, my, button);
        }

        // 标题栏空白区域才允许拖动
        if (mx >= x && mx <= x + WIDTH && my >= y && my <= y + TITLE_H) {
            dragging = true;
            dragOffsetX = (int) mx - x;
            dragOffsetY = (int) my - y;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            x = (int) mx - dragOffsetX;
            y = (int) my - dragOffsetY;
            repositionAll();
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    /** 拖动窗口时更新所有控件位置 */
    private void repositionAll() {
        if (historyTabBtn != null) historyTabBtn.setPosition(x + 8, y + TAB_Y);
        if (favoriteTabBtn != null) favoriteTabBtn.setPosition(x + 72, y + TAB_Y);

        // 底部按钮位置更新：从 children 里找出来，简单起见重建记录列表即可
        // 底部按钮位置也一起更新
        rebuildEntryList();
        // 注意：底部按钮没存字段，因此拖动后位置会偏移，需要时再补
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (mx >= x && mx <= x + WIDTH && my >= y && my <= y + HEIGHT) {
            scrollOffset = Math.max(0, Math.min(scrollOffset - (int) sy,
                Math.max(0, getFilteredEntries().size() - VISIBLE_ENTRIES)));
            rebuildEntryList();
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g, mx, my, pt);
        g.fill(x, y, x + WIDTH, y + HEIGHT, 0xE0101010);
        g.renderOutline(x, y, WIDTH, HEIGHT, 0xFF808080);
        g.fill(x, y, x + WIDTH, y + TITLE_H, 0xFF303030);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}