package com.example.clipboard;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;

@Mod(ClipboardMod.MODID)
public class ClipboardMod {
    public static final String MODID = "clipboard";

    public static ClipboardStorage activeStorage;

    public static final KeyMapping OPEN_CLIPBOARD = new KeyMapping(
        "key.clipboard.open",
        KeyConflictContext.UNIVERSAL,
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_C,
        "key.categories.clipboard"
    );

    public ClipboardMod(IEventBus modBus) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            modBus.addListener(this::registerKeyMappings);
            NeoForge.EVENT_BUS.addListener(this::onClientTick);
            NeoForge.EVENT_BUS.addListener(this::onKeyPressed);
            NeoForge.EVENT_BUS.addListener(this::onScreenInit);
        }
    }

    private void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_CLIPBOARD);
    }

    private void onKeyPressed(ScreenEvent.KeyPressed.Pre event) {
        Minecraft mc = Minecraft.getInstance();

        // Alt+C 打开剪贴板
        if (event.getKeyCode() == GLFW.GLFW_KEY_C
                && (event.getModifiers() & GLFW.GLFW_MOD_ALT) != 0) {
            mc.setScreen(new ClipboardScreen());
            event.setCanceled(true);
            return;
        }

        // 聊天框里按回车时，读取输入框内容并记录（覆盖普通聊天和指令）
        if (mc.screen instanceof ChatScreen chatScreen
                && (event.getKeyCode() == GLFW.GLFW_KEY_ENTER
                    || event.getKeyCode() == GLFW.GLFW_KEY_KP_ENTER)) {
            String text = getChatInput(chatScreen);
            if (text != null && !text.isBlank()) {
                ClipboardStorage s = getStorage();
                if (s != null) {
                    s.addEntry(text);
                    System.out.println("[Clipboard] 回车捕获: " + text
                                     + " 记录数=" + s.entries.size());
                }
            }
        }
    }

    /**
     * 用反射读取 ChatScreen 里的输入框内容。
     * 不同版本里输入框字段名可能不同，遍历所有字段找 EditBox 类型的即可。
     */
    private String getChatInput(ChatScreen chatScreen) {
        try {
            for (Field f : ChatScreen.class.getDeclaredFields()) {
                if (EditBox.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    EditBox box = (EditBox) f.get(chatScreen);
                    if (box != null) {
                        return box.getValue();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("[Clipboard] 反射读取输入框失败: " + e);
        }
        return null;
    }

    private void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        while (OPEN_CLIPBOARD.consumeClick()) {
            long window = mc.getWindow().getWindow();
            boolean altDown = InputConstants.isKeyDown(window, GLFW.GLFW_KEY_LEFT_ALT)
                           || InputConstants.isKeyDown(window, GLFW.GLFW_KEY_RIGHT_ALT);
            if (altDown) {
                mc.setScreen(new ClipboardScreen());
            }
        }
    }

    private void onScreenInit(ScreenEvent.Init.Post event) {
        if (event.getScreen() instanceof PauseScreen) {
            event.addListener(Button.builder(
                Component.literal("打开剪贴板"),
                b -> Minecraft.getInstance().setScreen(new ClipboardScreen())
            ).bounds(10, 10, 100, 20).build());
        }
    }

    // 单例：只在 activeStorage 为空时从存档加载，之后永远返回同一对象
    public static ClipboardStorage getStorage() {
        if (activeStorage != null) return activeStorage;

        Minecraft mc = Minecraft.getInstance();
        MinecraftServer server = mc.getSingleplayerServer();
        if (server == null && mc.level != null) {
            server = mc.level.getServer();
        }
        if (server == null) return null;

        activeStorage = server.overworld().getDataStorage().computeIfAbsent(
            new SavedData.Factory<>(ClipboardStorage::create, ClipboardStorage::load),
            ClipboardStorage.DATA_NAME
        );
        return activeStorage;
    }
}