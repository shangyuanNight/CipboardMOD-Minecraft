package com.example.clipboard;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

public class ClipboardStorage extends SavedData {
    public static final String DATA_NAME = "clipboard_history";
    public final List<ClipboardEntry> entries = new ArrayList<>();

    public static ClipboardStorage create() {
        return new ClipboardStorage();
    }

    public static ClipboardStorage load(CompoundTag tag, HolderLookup.Provider provider) {
        ClipboardStorage data = new ClipboardStorage();
        ListTag list = tag.getList("entries", 10);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entryTag = list.getCompound(i);
            data.entries.add(new ClipboardEntry(
                entryTag.getString("content"),
                entryTag.getLong("timestamp"),
                entryTag.getBoolean("pinned"),
                entryTag.getBoolean("favorite")
            ));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        ListTag list = new ListTag();
        for (ClipboardEntry entry : entries) {
            CompoundTag entryTag = new CompoundTag();
            entryTag.putString("content", entry.content);
            entryTag.putLong("timestamp", entry.timestamp);
            entryTag.putBoolean("pinned", entry.pinned);
            entryTag.putBoolean("favorite", entry.favorite);
            list.add(entryTag);
        }
        tag.put("entries", list);
        return tag;
    }

    public void addEntry(String content) {
        if (content == null || content.isBlank()) return;
        if (!entries.isEmpty() && entries.get(0).content.equals(content)) return;
        entries.add(0, new ClipboardEntry(content, System.currentTimeMillis(), false, false));
        pruneIfNeeded();
        setDirty();
    }

    public void pruneUnprotected() {
        entries.removeIf(e -> !e.pinned && !e.favorite);
        setDirty();
    }

    private void pruneIfNeeded() {
        final int MAX_HISTORY = 100;
        List<ClipboardEntry> unprotected = entries.stream()
            .filter(e -> !e.pinned && !e.favorite)
            .toList();
        int excess = unprotected.size() - MAX_HISTORY;
        if (excess > 0) {
            for (ClipboardEntry old : unprotected) {
                if (excess <= 0) break;
                if (entries.remove(old)) excess--;
            }
        }
    }
}